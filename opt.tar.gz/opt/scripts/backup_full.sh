#!/bin/bash
# backup_full.sh - Genera un backup comprimido (.tar.gz) de un directorio
# Uso: backup_full.sh <origen> <destino>
# Ejemplo: backup_full.sh /var/log /backup_dir -> /backup_dir/log_bkp_YYYYMMDD.tar.gz

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Genera un backup comprimido del directorio <origen> dentro de <destino>."
    echo "El archivo generado se llama <nombre>_bkp_YYYYMMDD.tar.gz (fecha ANSI)."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  -> genera /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
}

error() {
    echo "ERROR: $1" >&2
    exit "$2"
}

# Valida que el filesystem donde esta el directorio este disponible.
# Si el directorio es un punto de montaje declarado en /etc/fstab,
# verifica que este realmente montado.
validar_fs() {
    local dir="$1"
    if grep -qE "^[^#]*[[:space:]]${dir}[[:space:]]" /etc/fstab; then
        mountpoint -q "$dir" || error "el filesystem de $dir no esta montado" 4
    fi
    findmnt -T "$dir" > /dev/null 2>&1 || error "no se encuentra el filesystem de $dir" 4
}

# 1) Opcion de ayuda
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    mostrar_ayuda
    exit 0
fi

# 2) Cantidad de argumentos
if [ $# -ne 2 ]; then
    echo "ERROR: se necesitan 2 argumentos: origen y destino." >&2
    mostrar_ayuda
    exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2%/}"

# 3) Validar origen y destino
[ -d "$ORIGEN" ]  || error "el origen $ORIGEN no existe o no es un directorio" 2
[ -d "$DESTINO" ] || error "el destino $DESTINO no existe o no es un directorio" 3
validar_fs "$ORIGEN"
validar_fs "$DESTINO"
[ -w "$DESTINO" ] || error "no hay permiso de escritura en $DESTINO" 3

# 4) Armar el nombre: <nombre>_bkp_YYYYMMDD.tar.gz
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# 5) Generar el backup
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"
RC=$?

# tar devuelve 1 si algun archivo cambio mientras se leia (normal en logs)
if [ $RC -le 1 ]; then
    echo "Backup OK: $ARCHIVO"
    exit 0
else
    error "fallo el backup de $ORIGEN (codigo $RC)" 5
fi
