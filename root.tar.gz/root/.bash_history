history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
ping -c deb.debian.org
cat/etc/apt/sources.list
cat /etc/apt/sources.list
ls /etc/apt/sources.list.d/
ls /etc/apt/sources.list.d/
ls /etc/apt/sources.list.d
ls -l  /etc/apt/sources.list.d
ping -c 3 deb.debian.org
clear
cp /etc/apt/sources.list /etc/apt/sources.list.bak
nano /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-security main contrib non-free non-free-firmware" > /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-security main contrib non-free non-free-firmware" >> /etc/apt/sources.list
cat /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm main contrib non-free non-free-firmware" > /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware" >> /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware" >> /etc/apt/sources.list
clear
cat /etc/apt/sources.list
apt update
apt full-upgrade
clear
reboot
cat /etc/debian_version
uname -r
 ls -la /root
ls -la /root/.ssh
dpkg -l | grep openssh
tar -tzvf /root/Material_Adicional_TPVMCA.tar.gz
cd /root
tar -xzvf Material_Adicional_TPVMCA.tar.gz
apt install openssh-server
systemctl status ssh
clear
cat /root/Material_Adicional_TPVMCA/clave_publica.pub
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ls -la /root/.ssh
grep -n -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
sed -i 's/^#PermitRootLogin.*/PermitRootLogin prohibit-password/' /etc/ssh/sshd_config
sed -i 's/^#PubkeyAuthentication.*/PubkeyAuthentication yes/' /etc/ssh/sshd_config
grep -n -E "PermitRootLogin|PubkeyAuthentication" /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
apt install apache2 php libapache2-mod-php
systemctl status apache2
php -v
cat /etc/hosts
sed -i 's/127.0.1.1.*/127.0.1.1. TPServer/' /etc/host
sed -i 's/127.0.1.1.*/127.0.1.1. TPServer/' /etc/hosts
cat /etc/hosts
systemctl restart apache2
systemctl status apache2 --no-pager
sed -i 's/127.0.1.1. TPServer/127.0.1.1 TPServer/' /etc/hosts
clear
cat /etc/hosts
systemctl restart apache2
systemctl status apache2 --no-pager
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
mv /var/www/html/index.html /var/www/html/index.html.bak
ls -l /var/www/html
cat /var/www/html/index.php
ls -l /var/www/html
clear
apt install php-mysql
clear
head -n 20 /var/www/html/index.php
head -n 30 /root/Material_Adicional_TPVMCA/db.sql
apt install mariadb-server
systemctl status mariadb --no-pager
clear
mysql < /root/Material_Adicional_TPVMCA/db.sql
mesql -e "SHOW DATABSE; SELECT * FROM ingenieria.alumnos;"
mysql -e "SHOW DATABSES; SELECT * FROM ingenieria.alumnos;"
systemctl restart apache2
clear
mysql -e "SHOW DATABASES;"
mysql -e "SELECT * FROM ingenieria.alumnos;"
php /var/www/html/index.php | -n 
clear
php /var/www/html/index.php | head -n
php /var/www/html/index.php | head -n 30
ip a 
cat /etc/network/interfaces
ip route
clear
ping -c 2 192.168.1.200
cp /etc/network/interfaces /etc/network/interfaces.bak
sed -i 's/iface enp0s3 inet dhcp/iface enp0s3 inet static/' /etc/network/interfaces
sed -i 's/allow-hotplug enp0s3/auto enp0s3/' /etc/network/interfaces
echo "    address 192-168.1.200" >> /etc/network/interfaces
echo "    address 192.168.1.200" >> /etc/network/interfaces
echo "    geta 255.255.255.0" >> /etc/network/interfaces
echo "    gateway 192.168.1.1" >> /etc/network/interfaces
clear
cat/etc/network/interfaces
cat /etc/network/interfaces
sed -i '/192-168/d' /etc/network/interfaces
clear
cat /etc/network/interfaces
reboot
clear
ip a
ip route
ping -c 3 deb.debian.org
clear
cp /root/Material_Adicional_TPVMCA/clave_privada.txt /var/www/html/
chmod 644 /var/www/html/clave_privada.txt
rm /var/www/html/clave_privada.txt
rm -f /var/www/html/clave_privada.txt
ls /var/www/html
lsblk
poweroff
mkdir -p /opt/scripts
cat > /opt/scripts/backup_full.sh << 'EOF'
#!/bin/bash
# backup_full.sh - Genera un backup comprimido (.tar.gz) de un directorio
# Uso: backup_full.sh <origen> <destino>
# Ejemplo: backup_full.sh /var/log /backup_dir -> /backup_dir/log_bkp_YYYYMMDD.tar.gz

mostrar_ayuda() {
    echo "Uso: $0 <origen> <destino>"
    echo ""
    echo "Genera un backup comprimido del directorio <origen> dentro de <destino>."
    echo "El archivo generado se llama <nombre>_bkp_YYYYMMDD.tar.gz (fecha ANSI)."
    echo ""
    echo "Ejemplo:"
    echo "  $0 /var/log /backup_dir"
    echo "  -> genera /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz"
    echo ""
    echo "Opciones:"
    echo "  -help    Muestra esta ayuda"
}

error() {
    echo "ERROR: $1" >&2
    exit "$2"
}

# Valida que el filesystem donde esta el directorio este disponible.
# Si el directorio es un punto de montaje declarado en /etc/fstab,
# verifica que este realmente montado.
validar_fs() {
    local dir="$1"
    if grep -qE "^[^#]*[[:space:]]${dir}[[:space:]]" /etc/fstab; then
        mountpoint -q "$dir" || error "el filesystem de $dir no esta montado" 4
    fi
    findmnt -T "$dir" > /dev/null 2>&1 || error "no se encuentra el filesystem de $dir" 4
}

# 1) Opcion de ayuda
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    mostrar_ayuda
    exit 0
fi

# 2) Cantidad de argumentos
if [ $# -ne 2 ]; then
    echo "ERROR: se necesitan 2 argumentos: origen y destino." >&2
    mostrar_ayuda
    exit 1
fi

ORIGEN="${1%/}"
DESTINO="${2%/}"

# 3) Validar origen y destino
[ -d "$ORIGEN" ]  || error "el origen $ORIGEN no existe o no es un directorio" 2
[ -d "$DESTINO" ] || error "el destino $DESTINO no existe o no es un directorio" 3
validar_fs "$ORIGEN"
validar_fs "$DESTINO"
[ -w "$DESTINO" ] || error "no hay permiso de escritura en $DESTINO" 3

# 4) Armar el nombre: <nombre>_bkp_YYYYMMDD.tar.gz
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# 5) Generar el backup
tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"
RC=$?

# tar devuelve 1 si algun archivo cambio mientras se leia (normal en logs)
if [ $RC -le 1 ]; then
    echo "Backup OK: $ARCHIVO"
    exit 0
else
    error "fallo el backup de $ORIGEN (codigo $RC)" 5
fi
EOF

wc -l /opt/scripts/backup_full.sh
head -n 3 /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
ls -lh /backup_dir
systemctl status cron --no-pager
(crontab -l 2>/dev/null; echo "0 0 * * * /opt/scripts/backup_full.sh /var/log /backup_dir"; echo "0 23 * * 1,3,5 /opt/scripts/backup_full.sh /www_dir /backup_dir") | crontab -
crontab -l
clear
lsblk
fdisk /dev/sdc
clear
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir /backup_dir
cp /etc/fstab /etc/fstab.bak
clear
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dit ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /backup_dir ext4 defaults 0 2" >> /etc/fstab
mount -a
sed -i '/www_dit/d; /backup_dir/d' /etc/fstab
mkdir -p /www_dir /bakup_dir
echo "UUID=$(blkid -s UUID -o value /dev/sdc1) /www_dir ext4 defaults 0 2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2) /backup_dir ext4 defaults 0 2" >> /etc/fstab
clear
cat /etc/fstab
systemctl daemon-reload
mount -a
df -h | grep sdc
clear
cp /var/www/html/index.php /var/www/html/logo.png /www_dir/
ls -l /www_dir
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
cp /etc/apache2/apache2.conf /etc/apache2/apache2.conf.bak
sed -i 's#DocumentRoot /var/www/html#DocumentRoot /www_dir#' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
vi apache2.config
q!
:q!
q!
clear
cp/etc/apache2.conf.bak /etc/apache2/apache2.conf
rm -f /root/apache.config
grep DocmentRoot /etc/apache2/sites-available/000-default.conf
cp /etc/apache2.conf.bak /etc/apache2/apache2.conf
cp /etc/apache2/apache2.conf.bak /etc/apache2/apache2.conf
sed -i 's#DocumentRoot /var/www/html#DocumentRoot /www_dir#' /etc/apache2/sites-available/000-default.conf
grep DocumentRoot /etc/apache2/sites-available/000-default.conf
cat >> /etc/apache2/apache2.conf << 'EQF'
<Directory /www_dir/>
Options FollowSymLinks
AllowOverride none
Require all granted
</Directory>
EQF

tail -n 6 /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
cat /proc/partitions > /opt/particion
cat /opt/particion
clear
reboot
echo "== 1.3 hostname =="; hostname
echo "== 2.1 version =="; cat /etc/debian_version
echo "== 2.x servicios =="; systemctl is-active ssh apache2 mariadb cron
echo "== 2.3 php =="; php -v | head -n 1
echo "== 2.4 base =="; mysql -e "SELECT COUNT(*) AS alumnos FROM ingenieria.alumnos;"
echo "== 3 red =="; ip -4 addr show enp0s3 | grep inet; ip route | grep default
echo "== 4 montajes =="; df -h | grep sdc
echo "== 4.3 apache =="; grep DocumentRoot /etc/apache2/sites-available/000-default.conf; ls /www_dir
echo "== 4 nota =="; ls -l /opt/particion
echo "== 5 script y cron =="; ls -l /opt/scripts/backup_full.sh; crontab -l | grep backup
clear
